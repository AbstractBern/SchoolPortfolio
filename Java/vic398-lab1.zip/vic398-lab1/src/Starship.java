/**
 *	@author: Bernardo Flores
 *	Student ID: vic398
 * 	Date: 08/30/2018
 * 	Descr: The task of Starship.java is to return a 
 * 			string value of ship names, registry code,
 * 			and class to Fleet.java.
 */

//create class Starship
public class Starship 
{
	String sName;				//declare string sName 
	String registry;			//declare string registry
	String cType;				//declare string cType
	int count;					//declare int
	CrewMember[] members;		//declare array of CrewMember objects named members
	
	//Starship: constructor sets data for Starship.	@param: String name of starship, String registry code, String class type.
	public Starship(String name1, String reg1, String class1)
	{
		sName = name1;						//assigns sName to hold name of starship given
		registry = reg1;					//assigns registry to hold registry code given
		cType = class1;					//assigns cType to hold type of starship
		members = new CrewMember[11];		//assigns members array to hold 10 elements
	}
	public String getsName()					//getsName: @return String sName
	{
		return sName;
	}
	public String getReg()						//getReg: @return String registry code
	{
		return registry;
	}
	public String getcType()					//getcType: @return String -type of starship
	{
		return cType;
	}											
	public void addCrewMember(CrewMember crew)	//addCrewMember: sets the members array to hold crew. @param: CrewMember object.
	{
		members[count] = crew;
		count++;
	}
	public String toString()					//toString: @return Starship and CrewMember data in String format
	{
		String ret="";
		ret += sName + " " + "(" + registry + ")\n\n";
		ret += "[" + cType + "]\n";
		for (int i=0; i<count; i++)
			ret += members[i];
		return ret;
	}
}
