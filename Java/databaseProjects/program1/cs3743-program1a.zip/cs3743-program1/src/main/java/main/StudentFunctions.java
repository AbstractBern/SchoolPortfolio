package main;

import hashdb.HashFile;
import hashdb.HashHeader;
import hashdb.Vehicle;
import misc.ReturnCodes;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class StudentFunctions {
    /**
     * hashCreate
     * This function creates a hash file containing only the HashHeader record.
     * • If the file already exists, return RC_FILE_EXISTS
     * • Create the binary file by opening it.
     * • Write the HashHeader record to the file at RBN 0.
     * • close the file.
     * • return RC_OK.
     */
    public static int hashCreate(String fileName, HashHeader hashHeader) {
        File file = new File(fileName);
        if ( file.exists() ) {
            return ReturnCodes.RC_FILE_EXISTS;
        }
        try {   //writing to binary file but not writing to hash file?
            FileOutputStream hashFILE = new FileOutputStream(file);
            hashFILE.write(hashHeader.toByteArray());
            //System.out.println("****hashCreate works!\n");
            hashFILE.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return ReturnCodes.RC_OK;
    }

    /**
     * hashOpen
     * This function opens an existing hash file which must contain a HashHeader record
     * , and sets the file member of hashFile
     * It returns the HashHeader record by setting the HashHeader member in hashFile
     * If it doesn't exist, return RC_FILE_NOT_FOUND.
     * Read the HashHeader record from file and return it through the parameter.
     * If the read fails, return RC_HEADER_NOT_FOUND.
     * return RC_OK
     */
    public static int hashOpen(String fileName, HashFile hashFile) {
        File file = new File(fileName);
        if ( !file.exists() ) {
            System.out.print("File not exists in hashCreate\n");
            return ReturnCodes.RC_FILE_NOT_FOUND;
        }
        if ( file.length() == 0 ) {
            System.out.println("****File empty\n");
            return ReturnCodes.RC_HEADER_NOT_FOUND;
        }
        try {   //writing to binary file but not writing to hash file?
            FileInputStream thisFile = new FileInputStream(file);
            int length = thisFile.available();
            byte[] data = new byte[(int) length];
            thisFile.read(data);
            /*List<String> lines = new ArrayList<String>();
            String line;
            while ( ( line = thisFile.readLine()) != null ) {
                lines.add(line);
            }
            thisFile.close();
            line = lines.toString();
            //[HashHeader{maxHash=##, recsize=##, maxProbe=#}]
            Pattern p = Pattern.compile("\\d+");
            Matcher m = p.matcher(line);
            int inc = 0, max=0, rec=0, probe=0;
            while (m.find() ) {
                if (inc == 0){
                    max = Integer.valueOf(m.group());
                } else if (inc == 1) {
                    rec = Integer.valueOf(m.group());
                }else if (inc == 2) {
                    probe = Integer.valueOf(m.group());
                }
                inc++;
            }
            HashHeader newHash = new HashHeader(); // because we technically do not have one to write.
            newHash.setMaxHash(max);
            newHash.setMaxProbe(probe);
            newHash.setRecSize(rec);
            */
            HashHeader newHash = new HashHeader(); // because we technically do not have one to write.
            newHash.fromByteArray(data);
            thisFile.close();
            //hashFile.setHashHeader(newHash);
            RandomAccessFile toStore = new RandomAccessFile(file,"rw");
            toStore.close();
            hashFile.setFile(toStore);
        } catch (IOException e) {
            e.printStackTrace();
            System.out.println("****/ERROR!\n");
            return ReturnCodes.RC_HEADER_NOT_FOUND;
        }
        //System.out.println("****hashOpen works!\n");
        return ReturnCodes.RC_OK;
    }

    /**
     * vehicleInsert
     * This function inserts a vehicle into the specified file.
     * Determine the RBN using the Main class' hash function.
     * Use readRec to read the record at that RBN.
     * If that location doesn't exist
     * OR the record at that location has a blank vehicleId (i.e., empty string):
     * THEN Write this new vehicle record at that location using writeRec.
     * If that record exists and that vehicle's szVehicleId matches, return RC_REC_EXISTS.
     * (Do not update it.)
     * Otherwise, return RC_SYNONYM. a SYNONYM is the same thing as a HASH COLLISION
     * Note that in program #2, we will actually insert synonyms.
     */
    public static int vehicleInsert(HashFile hashFile, Vehicle vehicle) {
        int rbnPosition = Main.hash(vehicle.getVehicleId(), hashFile.getHashHeader().getMaxHash());
        int num = readRec(hashFile,rbnPosition,vehicle);
        if ( num == ReturnCodes.RC_LOC_NOT_FOUND ) { //|| vehicle.getVehicleId()[0] == '\0') {
            writeRec(hashFile,rbnPosition,vehicle);
            //System.out.println("****/vehicleInsert - writing.\n");
        }
        else if ( num == ReturnCodes.RC_OK ) { //|| curVeh.getVehicleId().equals(vehicle.getVehicleId()) ) {
            //System.out.println("****/vehicleInsert - exists.\n");
            return ReturnCodes.RC_REC_EXISTS;
        } else {
            return ReturnCodes.RC_SYNONYM;
        }
        //System.out.println("***/vehicleInsert - leaving.\n");
        return ReturnCodes.RC_OK;
    }
    /**
     * readRec(
     * This function reads a record at the specified RBN in the specified file.
     * Determine the RBA based on RBN and the HashHeader's recSize
     * Use seek to position the file in that location.
     * Read that record and return it through the vehicle parameter.
     * If the location is not found, return RC_LOC_NOT_FOUND.  Otherwise, return RC_OK.
     * Note: if the location is found, that does NOT imply that a vehicle
     * was written to that location.  Why?
      */
    public static int readRec(HashFile hashFile, int rbn, Vehicle vehicle) {
        try {
            RandomAccessFile toStore = new RandomAccessFile(String.valueOf(hashFile.getFile()), "rw");
            long RBA = (long) rbn * hashFile.getHashHeader().getRecSize();
            toStore.seek(RBA);
            if (RBA > toStore.length()) {
                return ReturnCodes.RC_LOC_NOT_FOUND;
            }
            //String str = "";
            //StringBuilder content = new StringBuilder();
            //while ( (str = toStore.readLine()) != null){
            //    content.append(str);
            //    System.out.print(str);
            //}
            /*String str;
            if (RBA > toStore.length()) {
                return ReturnCodes.RC_LOC_NOT_FOUND;
            }
            String content = "";
            while ( (str = toStore.readLine()) != null){
                content += str;
            }
            int numbersFound = 0;
            String id = "";
            String mkModel = "";
            String yr = "";
            for (char c: content.toCharArray()) {
                if (numbersFound < 3) {
                    if (Character.isLetter(c) ) {
                        id += c;
                    } else if (Character.isDigit(c)){
                        id += c;
                        numbersFound++;
                    }
                } else if ( numbersFound >= 3){
                    if (Character.isLetter(c) || Character.isSpaceChar(c)) {
                        mkModel += c;
                    }
                    else if (Character.isDigit(c)) {
                        yr += c;
                    }
                }
            }
            char[] vehID = id.toString().toString().toCharArray();    //.out.print(id);\
            String model = "";
            String make = "";
            Pattern p = Pattern.compile("([A-Z]+)([A-Za-z]+)");
            Matcher m = p.matcher(mkModel.toString().toString().toString());
            if(m.matches()){
                mkModel = m.group(1).toString();
                make = mkModel.substring(0,mkModel.length()-1);
                String last = mkModel.substring(mkModel.length()-1);
                model = last + m.group(2).toString();
            }
            Pattern q= Pattern.compile("(\\d+)");
            Matcher y = q.matcher(yr);
            int year = Integer.parseInt(y.group(1));

            //if(m.matches()){
            //    year = Integer.parseInt(y.group(1));
            //}
            char[] vehMk = make.toCharArray();
            char[] vehMd = model.toCharArray();
            vehicle.setVehicleId(vehID);
            vehicle.setYear(year);
            vehicle.setMake(vehMk);
            vehicle.setModel(vehMd);*/
            int length = hashFile.getHashHeader().getRecSize();
            byte[] data = new byte[(int)length];
            toStore.read(data);
            vehicle.fromByteArray(data);
            //vehicle.fromByteArray(data);
            //System.out.println(content);
            //toStore.seek(0);
            //vehicle.setVehicleId(vehicle.getVehicleId());
            //vehicle.setModel(vehicle.getModel());
            //vehicle.setMake(vehicle.getMake());
            //vehicle.setYear(Integer.parseInt(vehicle.getYearAsString()));
            toStore.close();
        } catch (IOException e) {
            e.printStackTrace();
            System.out.print("****/ERROR!\n");
            //should catch the positional not existing here
            return ReturnCodes.RC_LOC_NOT_FOUND;
        }
        //System.out.println("****/readRec - leaving.\n");
        return ReturnCodes.RC_OK;
    }

    /**
     * writeRec
     * This function writes a record to the specified RBN in the specified file.
     * Determine the RBA based on RBN and the HashHeader's recSize
     * Use seek to position the file in that location.
     * Write that record to the file.
     * If the write fails, return RC_LOC_NOT_WRITTEN.
     * Otherwise, return RC_OK.
     */
    public static int writeRec(HashFile hashFile, int rbn, Vehicle vehicle) {
        // open hash-file for raf writing
        try {
            RandomAccessFile toStore = new RandomAccessFile(String.valueOf(hashFile.getFile()),"rw");
            long RBA = (long) rbn * hashFile.getHashHeader().getRecSize();
            toStore.seek(RBA);
            toStore.write(vehicle.toByteArray());   //are we suppose to write vehicle or hash-header record?
            toStore.close();
        } catch (IOException e) {
            e.printStackTrace();
            System.out.println("****/ERROR!\n");
            return ReturnCodes.RC_LOC_NOT_WRITTEN;
        }
        //System.out.println("****writeRec - leaving.\n");
        return ReturnCodes.RC_OK;
    }

    /**
     * vehicleRead
     * This function reads the specified vehicle by its vehicleId.
     * Since the vehicleId was provided,
     * determine the RBN using the Main class' hash function.
     * Use readRec to read the record at that RBN.
     * If the vehicle at that location matches the specified vehicleId,
     * return the vehicle via the parameter and return RC_OK.
     * Otherwise, return RC_REC_NOT_FOUND
     */
    public static int vehicleRead(HashFile hashFile, int rbn, Vehicle vehicle) {
        Vehicle currentVehicle = vehicle;
        readRec(hashFile, rbn, currentVehicle);
        Vehicle tmpVehicle = currentVehicle;
        if (currentVehicle.getVehicleId() == tmpVehicle.getVehicleId()) {
            vehicle = tmpVehicle;
        } else {
            return ReturnCodes.RC_REC_NOT_FOUND;
        }
        //System.out.println("****/vehicleRead - leaving.\n");
        return ReturnCodes.RC_OK;
    }
}
