/**
 *	Name: Bernardo Flores
 *	Student ID: vic398
 * 	Date: 09/13/2018
 * 	Descr: The task of Starship.java is to return a 
 * 			string value of ship names, registry code,
 * 			and class to Fleet.java.
 */
import java.util.*;
//create class Starship
public class Starship 
{
	private String sName;				//declare string sName 
	private String registry;			//declare string registry
	private String cType;				//declare string cType
	ArrayList<CrewMember> members;		//declare ArrayList of CrewMember objects named members
	
	//Starship: constructor sets data for Starship.
	//			@param: string name of starship, string registry code, string class type.
	public Starship(String name1, String reg1, String class1)
	{
		sName = name1;						//assigns sName to hold name of starship given
		registry = reg1;					//assigns registry to hold registry code given
		cType = class1;						//assigns cType to hold type of starship
		members = new ArrayList<CrewMember>(16);//assigns ArrayList>CrewMember> to hold 16 elements
	}
	public String getsName()					//getsName: @return sName
	{
		return sName;
	}
	public String getReg()						//getReg: @return registry code
	{
		return registry;
	}
	public String getcType()					//getcType: @return class type of starship
	{
		return cType;
	}
	public ArrayList<CrewMember> getMembers()	//ArrayList<CrewMember> getMembers(): returns CrewMember object called members
	{
		return members;
	}
	public void addCrewMember(CrewMember crew)//addCrewMember: sets the members array to hold crew. @param: CrewMember object.
	{
		members.add(crew);
	}
	public void removeCrewMember(CrewMember crew)//removeCrewMember: removes a crew mem. @param: ArrayList<CrewMember> obj
	{
		members.remove(crew);
	}
	public String toString()					//toString: @return Starship and CrewMember data in string format
	{
		String ret="";
		ret += sName + " " + "[" + registry + "], " + "Class: " + cType + ", Crew: " + members.size();
		return ret;
	}
}