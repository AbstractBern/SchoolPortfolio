/**
 *	Name: Bernardo Flores
 *	Student ID: vic398
 * 	Date: 09/14/2018
 * 	Descr: The task of Fleet.java is to read two files into their respective objects from Starship.java 
 * 			or CrewMember.java into a fleet.
 */
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.*;
//create class Fleet
public class Fleet
{
	private String name;							//declare string name
	int sCount;										//declare int sCount;
	ArrayList<Starship> ships;						//declare ArrayList of Starship objects called ships
	
	public Fleet(String strName)					//Fleet: constructor to assign name and ship count. @param: string name of fleet
	{
		name = strName;								//assign fleet name;
		ships = new ArrayList<Starship>(8);			//assign ships ArrayList to hold 3 Starship objects
	}
	public void setStarship(ArrayList<Starship> ship)//setStarship: to set the number of ships. @param: Starship object array.
	{
		ships.addAll(ship);							//assigns ships to an array of ship
	}
	public void addStarship(Starship ship)			//addStarship: adds ship into Starship array. @param: Starship object array.
	{
		ships.add(ship);							//allocates the ship to cell
	}
	//reassign: reassigns a member by registry to another starship. @param: CrewMember object, String registry
	public void reassign(CrewMember member, String registry)
	{
		for (int i=0; i<ships.get(i).members.size(); i++)	//loop through members size
		{
			if (ships.get(i).members.get(i).equals(member));//test if member in array equals member to be removed
			{
				ships.get(i).members.remove(member);		//remove member from arrayList CrewMember
			}
			if (ships.get(i).getReg().equals(registry))		//test if registry is registry to move new member
			{
				ships.get(i).addCrewMember(member);			//assigns member to the ship new registry is in
			}
		}
	}
	//save: saves curent fleet info and overwrites files provided. @param: n/a
	public void save()
	{
		try
		{
			File fleetOut = new File("Fleet.csv");
			FileWriter fleet = new FileWriter(fleetOut);
			File shipOut = new File("Personnel.csv");
			FileWriter ship= new FileWriter(shipOut);
			for (int i=0; i<ships.size(); i++)
			{
				fleet.write(ships.get(i).toString());
			}
			for (int i=0; i<ships.get(i).members.size(); i++)
			{
				ship.write(ships.get(i).getMembers().toString());
			}
			
			fleet.close();
			ship.close();
		}	
		catch(IOException e)
		{
			e.printStackTrace();
		}
	}
	//loadStarships: loads data from file into starship object. @param: String fileName.
	public void loadStarships(String starshipFile) throws IOException
	{
		File shipFile = new File(starshipFile);		// open file for reading
		Scanner scan = new Scanner( shipFile );
		
		while(scan.hasNextLine())					//read line
		{
			String fileLine = scan.nextLine();		//string to scan next line in file
			String[] tokens = fileLine.split(",");	//split string into array
			
			String name = tokens[0];				//create string to hold first token
			String registry = tokens[1];			//create string to hold second token
			String cPos = tokens[2];				//create string to hold third token
			Starship obj = null;					//create null object
			obj = new Starship(name, registry, cPos);//give obj  Starship traits
			ships.add(obj);							//add ships to fleet
			
		}
		scan.close();								// close file
	}
	//loadCrew: loads data from file into crewMember object. @param: String File. @throws IOException.
	public void loadCrew(String crewMemberFile) throws IOException
	{
		File crewFile = new File(crewMemberFile);		// open file for reading
		Scanner scan = new Scanner( crewFile );	
		while(scan.hasNextLine())						//read line
		{
			String line = scan.nextLine();				//create line to scan next line in file
			String[] tokens = line.split(",");			//create tokens to split line by comma
			
			
			String name = tokens[0];					//create name and give it tokens[0]
			String position = tokens[1];				//create position and assign it tokens[1]
			String rank = tokens[2];					//create rank and assign it tokens[2]
			String registry = tokens[3];				//create registry and assign it tokens[3]
			String species = tokens[4];					//create species and assign it tokens[4]
			
			CrewMember member = null;					//create instane of CrewMember object null called member
			member = new CrewMember(rank,name,position,species);	//define CrewMember object member
			for (int i=0; i<ships.size(); i++)						//loop through lenth of ships
			{
				if (ships.get(i).getReg().equals(registry))			//if ships registry equals file registry number
				{
					ships.get(i).addCrewMember(member);				//access ships index and add member
				}
			}
		}
		scan.close();									// close file
	}
	public String toString()							//toString: @return ArrayList ships and CrewMember from respective classes in string format
	{
		String ret = name + "\n\n";						//assign string ret.
		for( int i=0; i<ships.size(); i++ )				//loop the length of ships to print out the ships and crew  in each fleets
		{	
				//get rid of comma on the indent and leave the commas next to names because of output design
				//also is save saving the write way
			ret += ships.get(i) + "\n";		
			ret += ships.get(i).getMembers().toString().replace(",","").replace("[","").replace("]","");	//replace to take out unwanted characters
		}
		return ret;
		
	}
}