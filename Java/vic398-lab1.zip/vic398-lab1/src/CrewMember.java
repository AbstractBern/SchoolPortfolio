/**
 *	@author: Bernardo Flores
 *	Student ID: vic398
 * 	Date: 08/30/2018
 * 	Descr: The task of CrewMember.java is to return a 
 * 			string value of members and their positions
 * 			that have been added to a CrewMember object.
 */

//create class CrewMember
public class CrewMember
{
	String cName;				//declare string cName value to hold name
	String cPosition;			//declare string cPosition value to hold title position
	int crewCount;				//declare int crewCount to hold a count of members
	
	//CrewMember: creates a constructor to hold a name and position value as a string
	//			@param: string name of member,string position of member
	public CrewMember(String name, String position)	
	{
		cName = name;			//sets cName to given name
		cPosition = position;	//sets cPosition to given title position
	}
	public String getName()			//getName: @return String cName
	{
		return cName;	//return 
	}
	public String getPosition()		//getPosition: @return String cPosition
	{
		return cPosition;
	}
	public String toString()		//toString: @return string representation of crew members and their positions
	{
		String crew="";
		crew = "-" + this.cPosition + ": " + this.cName + "\n";
		return  crew;
	}
}
