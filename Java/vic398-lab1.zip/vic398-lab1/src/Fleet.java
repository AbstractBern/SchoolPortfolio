/**
 *	@author: Bernardo Flores
 *	Student ID: vic398
 * 	Date: 08/30/2018
 * 	Descr: The task of Fleet.java is to return data from Starship.java 
 * 			and CrewMember.java as a Fleet object and to run the entire application.
 */

//create class Fleet
public class Fleet
{
	String name;								//declare String name
	int sCount;									//declare int sCount;
	Starship[] ships;							//declare array of Starship objects called ships
	
	public Fleet(String strName)				//Fleet: constructor to assign name and ship count. @param: string name of fleet
	{
		name = strName;							//assign String fleet name;
		ships = new Starship[3];				//assign ships array to hold 3 Starship objects
	}
	public void setStarship(Starship[] ship)	//setStarship: to set the number of ships. @param: Starship object array.
	{
		ships = ship;							//assigns ships to an array of ship
		sCount = ship.length;					//assigns sCount the number of ships counted for
	}
	public void addStarship(Starship ship)		//addStarship: adds ship into Starship array. @param: Starship object array.
	{
		ships[sCount] = ship;				//allocates the ship to cell
		sCount++;							//increment ship count
	}
	public String toString()					//toString: @return data from Starship object in String format
	{
		String ret = name + "\n\n";				//assign string ret
		for( int i=0; i<sCount; i++ )
		{
			ret += this.ships[i].toString() + "\n\n";
		}
		return ret;
	}
	public static void main(String[] args)	//main functiong provided to us to complete and interact with the rest of the classes
	{
		//add Fleet object
		Fleet federation = new Fleet("United Federation of Planets");
		//add Starship object
		Starship enterpriseA = new Starship("USS Enterprise", "NCC-1701-A", "Constitution");
		Starship enterpriseD = new Starship("USS Enterprise", "NCC-1701-D", "Galaxy");
		//add CrewMember object
		CrewMember jamesKirk = new CrewMember("James T. Kirk", "Commanding Officer");
		CrewMember spock = new CrewMember("Spock", "First Officer");
		CrewMember leonardMcCoy = new CrewMember("Leonard McCoy", "Chief Medical Officer");
		CrewMember montgomeryScott = new CrewMember("Montgomery Scott", "Chief Engineering Officer");
		CrewMember jeanLucPicard = new CrewMember("Jean-Luc Picard", "Commanding Officer");
		CrewMember williamRiker = new CrewMember("William T. Riker", "First Officer");
		CrewMember beverlyCrusher = new CrewMember("Beverly Crusher", "Chief Medical Officer");
		CrewMember geordiLaForge = new CrewMember("Geordi La Forge", "Chief Engineering Officer");
		//assign Starship obj to add crew
		enterpriseA.addCrewMember(jamesKirk);
		enterpriseA.addCrewMember(spock);
		enterpriseA.addCrewMember(leonardMcCoy);
		enterpriseA.addCrewMember(montgomeryScott);
		enterpriseD.addCrewMember(jeanLucPicard);
		enterpriseD.addCrewMember(williamRiker);
		enterpriseD.addCrewMember(beverlyCrusher);
		enterpriseD.addCrewMember(geordiLaForge);
		//add Starship and CrewMember to Fleet
		federation.addStarship(enterpriseA);
		federation.addStarship(enterpriseD);

		System.out.println(federation);
	}
}
