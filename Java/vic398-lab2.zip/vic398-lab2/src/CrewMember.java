/**
 *	@author: Bernardo Flores
 *	Student ID: vic398
 * 	Date: 09/13/2018
 * 	Descr: The task of CrewMember.java is to return a 
 * 			string value of members and their positions
 * 			that have been added to a CrewMember object.
 */
//create class CrewMember
public class CrewMember
{
	private String cName;				//declare string cName value to hold name
	private String cPosition;			//declare string cPosition value to hold title position
	private String rank;				//declare string rank value to hold rank name
	private String species;				//declare string species value to hold species types
	
	//CrewMember: creates a constructor to hold a rank, name, position, and species
	//			@param: string name of member,string position of member
	public CrewMember(String rank, String name, String cPosition, String species)	
	{
		this.rank = rank;				//sets rank to given rank name
		this.cName = name;			//sets cName to given name
		this.cPosition =cPosition;		//sets cPosition to given title position
		this.species = species;		//sets species to given specie
	}
	public String getName()			//getName: @return cName
	{
		return cName;	//return 
	}
	public String getPosition()		//getPosition: @return cPosition
	{
		return cPosition;
	}
	public String getRank()			//getRank: @return rank
	{
		return rank;
	}
	public String getSpecie()		//getSpecie: @return species
	{
		return species;
	}
	public String toString()		//toString: @return string representation of rank, name, position and species
	{
		String crew="";
		crew = " - " + this.rank + " " + this.cName + ", " + this.cPosition + "  (" + this.species + ")\n";
		return  crew;
	}
}