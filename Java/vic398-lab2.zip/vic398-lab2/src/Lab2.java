/**
 *	@author: Bernardo Flores
 *	Student ID: vic398
 * 	Date: 09/14/2018
 * 	Descr: The task of Lab2.java is to run a main method that
 * 			instantiates a new Fleet ex: new Fleet("string name"). The main
 * 			method runs a try-catch in which it runs two files:
 * 			loadStarships("file") and loadCrew("file") if it works all data 
 * 			will be declared and retured to the user, else catch:
 * 			a IOException handles an error and prompts Error message
 * 			with a trace of the error.
 */
import java.io.IOException;								//import java.io.IOException to handle error
 //create class Lab2: uses main funct to run entire application consisting of Fleet.j, Starship.J, CrewMember.j.
public class Lab2
{
	public static void main( String[] args )
	{
		/**		main(String[] args): runs entire program and instantiates a new Fleet object
		 * 							also it runs a try catch statement.
		 * 							try: to load both fleet and personnel files
		 * 							catch: handle an IOException
		 * 		@param: String[] args
		 * 
		 */
		Fleet federation = new Fleet( "United Federation of Planets" ); 	//instantiate Fleet into federation. @param: name of new Fleet
		try
		{																	//data for Fleet object should be gathered here
			federation.loadStarships( "fleet.csv" ); 						//call loadStarships to read fleet.csv file @param Starship File
			federation.loadCrew( "personnel.csv" );							//call loadCrew to read personnel.csv file	@param: Crew File
		}
		catch( IOException e )												//catch IOException handling
		{ 
			System.out.println( "Error loading the file - please check its location." ); //prompt for error
			e.printStackTrace();														//track error
		} 
		System.out.println( federation ); 									//print Fleet object
	}  
 } 